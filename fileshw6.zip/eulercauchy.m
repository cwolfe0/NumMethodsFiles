function yp=eulercauchy(x,y) 
yp=[y(2);(-.75*y(1))/x^2-(3*y(2))/x];