function dT = d2Tdx2hw(x,T) 
dT = [ T(2); -5*T(1)+.1*x]; 
