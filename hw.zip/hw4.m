%% Question 1
A = [8,-2,-3;-2,6,1;-3,1,7];
b = [-20;-38;-34];
%a.
[m,n]=size(A);
p = length(b); 
np1 = n+1; 
Aug = [A,b]; 
% forward elimination 
for k = 1:n-1 
    for i = k+1:n 
        factor = Aug(i,k) / Aug(k,k); 
        Aug(i,k:np1) = Aug(i,k:np1) - factor * Aug(k,k:np1); 
    end
end
% backward elimination 
x(n,1) = Aug(n,np1) / Aug(n,n); 
for i = n-1:-1:1 
    x(i) = (Aug(i,np1)-Aug(i,i+1:n)*x(i+1:n))/Aug(i,i); 
end
x
%b.
u = chol(A)
y = b\u;
y = [y(1);y(2);y(3)]
x2 = y\u'
x2 = [x(1);x(2);x(3)]
%c. 
A*x
A*x2
%% Q2.
clear
A = [15,3,1;3,18,6;4,1,5];
b = [-400;-150;-240];
p = [0,0,0];
u = chol(A);
y = b\u;
y = [y(1);y(2);y(3)];
x2 = y\u';
q = 1;
if q>.05
for i = 1:5
    z = 0;
    for j = 1:5
        if j~= i
           % z = z+A(i,j).*p(j)
        end
    end
  %  p(i) = (1./(A(i,i)))*b(i-z)
end
 %q = x2/p;
end
%% Q3.


% Both 2 and 3 don't work.